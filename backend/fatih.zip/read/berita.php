<?php
//koneksi
// definisikan koneksi ke database
 include '../koneksi.php';
    //query untuk menampilkan semua data ditable
    $sql=mysqli_query($con,"SELECT * FROM berita ORDER BY id_berita desc");
    // $sql1=mysqli_query($con,"SELECT count(id_data) FROM data_kendaraan");

    //untuk menampung isi data
    $response=array();
    $cek=mysqli_num_rows($sql);
    // echo $cek;
    if($cek >0){
        $response["berita"]=array();
        //perulangan
        while ($row=mysqli_fetch_array($sql)){
            $data=array();
            $data["id_berita"]=$row["id_berita"];
            $data["judul"]=$row["judul"];
            // $data["artikel"]=htmlspecialchars(utf8_encode($row["artikel"]));
            $data["artikel"]= utf8_encode($row["artikel"]);
            $data["gambar"]=$row["gambar"];
            $data["tanggal"]=$row["tanggal"];
        
         $response["pesan"]="berhasil Mengambil Data";
         $response["sukses"]="true";
         //banyaknya data
         $response["count"]= $cek;
            array_push($response["berita"],$data);
        }
        //mengubah data menjadi JSON
        // echo json_encode($response);

        //cek error
        $json = json_encode($response);

        if ($json)
            echo $json;
        else
            echo json_last_error_msg();

        //log
        // echo print_r($response);
    }else{
        $response["pesan"]="Gagal Mengambil Data";
        $response["sukses"]="false";
        echo json_encode($response);
    } 

?>