<?php
// include file koneksi
require '../koneksi.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $id = $_POST['id'];    

     $query = mysqli_query($con, "SELECT * FROM chat a JOIN admin b ON a.id_admin = b.id_admin JOIN user c ON a.id_user = c.id_user WHERE b.id_admin = '1' AND c.id_user = '$id'");
       $response=array();
        $count = mysqli_num_rows($query);
          if($count>0) {

            $response["chat"]=array();        
            while ($row=mysqli_fetch_array($query)){
                $data=array();

                $result=mysqli_query($con, "SELECT COUNT(*) total FROM chat a WHERE a.id_user = '$id' AND a.id_admin = '1'");
                $count=mysqli_fetch_assoc($result);

                $data["id_chat"]=$row["id_chat"];
                $data["id_user"]=$row["id_user"];
                $data["id_admin"]=$row["id_admin"];
                $data["nama_user"]=$row["nama"];
                $data["nama_admin"]=$row["7"];
                $data["pesan"]=$row["pesan"];
                $data["waktu"]=$row["waktu"];
                $data["kode"]=$row["code"];

                $response["total"]=$count['total'];                
                $response["msg"]=trim("success.");
                $response["code"]=200;
                $response["status"]=true;
                array_push($response["chat"],$data);
                // print_r($data);
            }

            echo json_encode($response);

        } else {

            $response["msg"]=trim("not succes");
            $response["code"]=400;
            $response["status"]=false; 
            echo json_encode($response);

        }

} else {

            $response["msg"]=trim("failed get data");
            $response["code"]=401;
            $response["status"]=false; 
    echo json_encode($response);
}
