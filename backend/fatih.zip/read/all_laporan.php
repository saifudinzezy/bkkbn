<?php
//koneksi
// definisikan koneksi ke database
 include '../koneksi.php';

    $sql = "";

    //jika id kosong
    
   if(isset($_POST['id'])){
        //jika post ada untuk memilih salah satu user
        $id = $_POST['id'];
        $sql=mysqli_query($con,"SELECT *
                FROM pelaporan a
                LEFT JOIN user b
                ON 
                a.id_user = b.id_user
                WHERE a.id_user = '$id'
                ORDER BY a.id_lapor DESC");
    }else{
        $sql=mysqli_query($con,"SELECT *
                FROM pelaporan a
                LEFT JOIN user b
                ON 
                a.id_user = b.id_user                    
                ORDER BY a.id_lapor DESC"); 
    }
  
    //query untuk menampilkan semua data ditable
    // $sql=mysqli_query($con,"SELECT * FROM jadwal_tranfusi ORDER BY id_tranfusi desc");
    //untuk menampung isi data
    $response=array();
    $cek=mysqli_num_rows($sql);
    if($cek >0){
        $response["pelaporan"]=array();
        //perulangan
        while ($row=mysqli_fetch_array($sql)){
            $data=array();
            $data["id_lapor"]=$row["id_lapor"];
            $data["id_user"]=$row["id_user"];
            $data["nama"]=$row["nama"];
            $data["hub_pelap"]=$row["hub_pelap"];
            $data["nama_korban"]=$row["nama_korban"];
            $data["jk_korban"]=$row["jk_korban"];
            $data["usia_korb"]=$row["usia_korb"];
            $data["alamat_korban"]=$row["alamat_korban"];
            $data["nm_pelaku"]=$row["nm_pelaku"];
            $data["jk_pelaku"]=$row["jk_pelaku"];
	           $data["hub_pelaku"]=$row["hub_pelaku"];
            $data["jenis_ks"]=$row["jenis_ks"];
            $data["tgl_kej"]=$row["tgl_kej"];
            $data["kronologi"]=$row["kronologi"];
            $data["status"]=$row["status"];
            $data["gambar"]=$row["gambar"];
            $data["pesan"]=$row["pesan"];                
            
            $response["pesan"]="berhasil Mengambil Data";
            $response["response"]="true";    
            array_push($response["pelaporan"],$data);
            //print_r($row);
        }
        //mengubah data menjadi JSON
        echo json_encode($response);
    }else{
        $response["pesan"]="Gagal Mengambil Data";
        $response["response"]="false";
        echo json_encode($response);
    } 

?>