<?php
// include file koneksi
require '../koneksi.php';
if($_SERVER['REQUEST_METHOD'] == 'GET'){
     $query = mysqli_query($con, "SELECT * FROM chat a JOIN admin b ON a.id_admin = b.id_admin JOIN user c ON a.id_user = c.id_user GROUP BY c.nama");
       $response=array();
        $count = mysqli_num_rows($query);
          if($count>0) {

            $response["chat"]=array();        
            while ($row=mysqli_fetch_array($query)){
                $data=array();            

                $data["id_chat"]=$row["id_chat"];
                $data["id_user"]=$row["id_user"];
                $data["id_admin"]=$row["id_admin"];
                $data["nama"]=$row["nama"];
                $data["jenkel"]=$row["jenkel"];
                $data["pesan"]=$row["pesan"];
                $data["waktu"]=$row["waktu"];

                $d = $row["id_user"];
                $result2=mysqli_query($con, "SELECT * FROM chat a WHERE a.id_user = '$d' ORDER BY a.id_chat DESC LIMIT 1");
                $count2=mysqli_fetch_assoc($result2);
                $data["pesan"]=$count2['pesan'];

                //count
                $result=mysqli_query($con, "SELECT COUNT(*) total FROM chat a WHERE a.id_user = '$d' AND a.id_admin = '1'");
                $count=mysqli_fetch_assoc($result);
                $data["total"]=$count['total'];                

                $response["msg"]=trim("success.");
                $response["code"]=200;
                $response["status"]=true;
                array_push($response["chat"],$data);
                // print_r($data);
            }

            echo json_encode($response);

        } else {

            $response["msg"]=trim("not succes");
            $response["code"]=400;
            $response["status"]=false; 
            echo json_encode($response);

        }

} else {

            $response["msg"]=trim("failed get data");
            $response["code"]=401;
            $response["status"]=false; 
    echo json_encode($response);
}
