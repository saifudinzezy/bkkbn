-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2019 at 04:59 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fatih`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `sandi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `email`, `sandi`) VALUES
(1, 'saifudin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id_berita` int(111) NOT NULL,
  `judul` text,
  `artikel` text,
  `gambar` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `judul`, `artikel`, `gambar`, `tanggal`) VALUES
(1, 'sayang anak', 'pakaillah kondom', 'fayi.jpg', '2019-05-14'),
(2, 'saifudi dan mila', 'haruskah bersama', '20170828_094815.jpg', '2019-05-14'),
(3, 'anu', 'anu', 'download.jpg', '2010-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id_chat` int(11) NOT NULL,
  `id_user` int(11) DEFAULT '0',
  `id_admin` int(11) DEFAULT NULL,
  `pesan` text,
  `waktu` datetime DEFAULT NULL,
  `code` int(11) DEFAULT NULL COMMENT '1 = admin, 0 = user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id_chat`, `id_user`, `id_admin`, `pesan`, `waktu`, `code`) VALUES
(1, 6, 1, 'hello', '2019-07-23 19:09:05', 0),
(2, 6, 1, 'iya?', '2019-07-23 19:09:07', 1),
(3, 6, 1, 'saya mau tanya?', '2019-07-23 19:09:37', 0),
(4, 6, 1, 'tanya apa?', '2019-07-23 19:09:57', 1),
(6, 11, 1, 'HAY?', '2019-07-24 04:05:21', 0),
(7, 11, 1, 'Terima Kasih.', '2019-03-03 21:09:03', 0),
(12, 6, 1, 'Admin?', '2019-07-24 14:42:17', 0),
(13, 6, 1, 'iya ada apa?', '2019-07-24 22:26:37', 1),
(15, 11, 1, 'ada yang bisa saya bantu ?', '2019-07-24 22:39:48', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pelaporan`
--

CREATE TABLE `pelaporan` (
  `id_lapor` int(11) NOT NULL,
  `id_user` int(15) DEFAULT NULL,
  `hub_pelap` varchar(20) DEFAULT NULL,
  `nama_korban` varchar(50) DEFAULT NULL,
  `jk_korban` varchar(20) DEFAULT NULL,
  `usia_korb` int(2) DEFAULT NULL,
  `alamat_korban` varchar(50) DEFAULT NULL,
  `nm_pelaku` varchar(50) DEFAULT NULL,
  `jk_pelaku` varchar(20) DEFAULT NULL,
  `hub_pelaku` varchar(20) DEFAULT NULL,
  `jenis_ks` varchar(20) DEFAULT NULL,
  `tgl_kej` date NOT NULL,
  `kronologi` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT '',
  `gambar` varchar(1000) DEFAULT NULL,
  `pesan` text,
  `s_pelapor` varchar(50) DEFAULT NULL,
  `s_korban` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelaporan`
--

INSERT INTO `pelaporan` (`id_lapor`, `id_user`, `hub_pelap`, `nama_korban`, `jk_korban`, `usia_korb`, `alamat_korban`, `nm_pelaku`, `jk_pelaku`, `hub_pelaku`, `jenis_ks`, `tgl_kej`, `kronologi`, `status`, `gambar`, `pesan`, `s_pelapor`, `s_korban`) VALUES
(1, 6, 'anu', 'anu', 'anu', 12, 'anu', 'anu', 'Perempuan', 'Saudara', 'Kekerasan', '2019-02-02', 'anu', 'Menunggu', '1563810950633.jpg', '', NULL, NULL),
(2, 6, 'Saudara', 'ww', 'Laki - Laki', 12, 'Ww', 'ww', 'Laki - Laki', 'Tetangga', 'Kekerasan Seksual', '2019-07-16', 'sww', 'Menunggu', '1564309973244.jpg', '-', NULL, NULL),
(3, 6, 'Keluarga', 'nk', 'Laki - Laki', 0, 'Jj', 'jj', 'Laki - Laki', 'Saudara', 'Kekerasan Fisik', '2019-07-27', 'jej', 'Menunggu', '1564311894935.jpg', '-', 'Lajang', 'Lajang');

-- --------------------------------------------------------

--
-- Table structure for table `tb_message`
--

CREATE TABLE `tb_message` (
  `message_id` int(6) NOT NULL,
  `message_body` text NOT NULL,
  `message_sender` varchar(20) NOT NULL,
  `message_to` varchar(20) NOT NULL,
  `message_unread` int(1) NOT NULL,
  `message_post_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_message`
--

INSERT INTO `tb_message` (`message_id`, `message_body`, `message_sender`, `message_to`, `message_unread`, `message_post_date`) VALUES
(1, 'Ada dimana bro', '1', '2', 1, '2018-08-09 10:00:00.000000'),
(2, 'Ada Dikantor', '2', '1', 1, '2018-08-10 01:12:05.763390'),
(4, 'nga ada dimana ?', '2', '1', 1, '2018-08-10 01:14:51.279489'),
(5, 'kita ada di kantor', '1', '2', 1, '2018-08-10 01:14:56.479262'),
(6, 'Kapan kitorang bakudapa?', '1', '2', 1, '2018-08-10 07:47:43.677220'),
(7, 'ngana suka kapan ?', '2', '1', 1, '2018-08-10 07:48:11.502027'),
(8, 'bagaimana hari minggu bro ?', '2', '1', 1, '2018-08-10 07:48:22.541881'),
(9, 'bro marijo cabut ', '1', '2', 0, '2018-08-10 09:04:12.064330'),
(10, 'bagaimana hari minggu bro ?', '2', '1', 1, '2018-08-10 09:05:25.425505'),
(11, 'bro marijo cabut ', '1', '2', 0, '2018-08-10 09:06:15.152004'),
(12, 'bro marijo cabut ', '1', '2', 0, '2018-08-10 09:09:19.778932'),
(13, 'broo', '1', '2', 0, '2018-08-10 09:10:48.154337'),
(14, 'broo', '1', '2', 0, '2018-08-10 09:16:09.521099'),
(15, 'bagaimana hari minggu bro ?', '2', '1', 1, '2018-08-10 09:16:57.901108'),
(16, 'bagaimana hari minggu bro ?', '2', '1', 1, '2018-08-10 09:20:59.195545'),
(17, 'broo', '1', '2', 0, '2018-08-10 09:21:23.575053'),
(18, 'broo', '1', '2', 0, '2018-08-10 09:21:30.473350'),
(19, 'kk', '1', '2', 0, '2018-08-10 09:22:53.663808');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenkel` varchar(25) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `rt` varchar(25) DEFAULT NULL,
  `desa` varchar(25) DEFAULT NULL,
  `kec` varchar(25) DEFAULT NULL,
  `kabupaten` varchar(25) DEFAULT NULL,
  `agama` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nik`, `nama`, `tempat_lahir`, `tanggal_lahir`, `jenkel`, `alamat`, `rt`, `desa`, `kec`, `kabupaten`, `agama`, `password`) VALUES
(1, '1234567890', 'user', 'pekalongan', '1994-01-01', 'laki-laki', 'dusun kajen', '001/002', 'kajen', 'kajen', 'pekalongan', 'protestan', 'user'),
(6, '88888888', 'wati', 'pekok', '2019-05-01', 'Perempuan', 'popo', '09/09', 'kolok', 'klkl', 'klkjl', 'Islam', 'anam'),
(7, '0000000005', 'aslam', 'pekalongan', '2019-06-04', 'Laki - Laki', 'hajaha', '08/09', 'java', 'jaya', 'jaka', 'Kristen', 'aslam'),
(11, '1818181818181', 'ali', 'pekalongan', '2019-06-24', 'Laki - Laki', 'kajen', '07/01', 'kajen', 'kajen', 'pekalongan', 'Islam', 'saifudin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id_chat`);

--
-- Indexes for table `pelaporan`
--
ALTER TABLE `pelaporan`
  ADD PRIMARY KEY (`id_lapor`);

--
-- Indexes for table `tb_message`
--
ALTER TABLE `tb_message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id_berita` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id_chat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pelaporan`
--
ALTER TABLE `pelaporan`
  MODIFY `id_lapor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_message`
--
ALTER TABLE `tb_message`
  MODIFY `message_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
