<?php 
	include '../koneksi.php';

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$id_user = $_POST['id_user'];
		$id_admin = $_POST['id_admin'];
		$pesan = $_POST['pesan'];
		$waktu = $_POST['waktu'];
		$kode = $_POST['kode'];
	
        //query untuk menambahkan data
		$query = "INSERT INTO chat VALUES (null, '$id_user', '$id_admin', '$pesan', '$waktu', '$kode')";

		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'Data berhasil disimpan')) : json_encode(array('code' => 400, 'message' => 'data gagal disimpan'));
	} else{
		echo json_encode(array('code' => 404, 'message' => 'request tidak valid'));
	}
 ?>