<?php 
	include '../koneksi.php';

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$nik = $_POST['nik'];
		$nama = $_POST['nama'];
		$tempat_lahir = $_POST['tempat_lahir'];
		$tanggal_lahir = $_POST['tanggal_lahir'];
		$jenkel = $_POST['jenkel'];
		$alamat = $_POST['alamat'];
		$rt = $_POST['rt'];
		$desa = $_POST['desa'];
		$kec = $_POST['kec'];
		$kabupaten = $_POST['kabupaten'];
		$agama = $_POST['agama'];
		$password = $_POST['password'];
	
        //query untuk menambahkan data
		$query = "INSERT INTO user VALUES (null, '$nik', '$nama', '$tempat_lahir', '$tanggal_lahir', '$jenkel', '$alamat', '$rt', '$desa', 
			'$kec', '$kabupaten', '$agama', '$password')";

		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'Data berhasil disimpan')) : json_encode(array('code' => 400, 'message' => 'data gagal disimpan'));
	} else{
		echo json_encode(array('code' => 404, 'message' => 'request tidak valid'));
	}
 ?>