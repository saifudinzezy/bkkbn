<?php 
	include '../koneksi.php';

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$id_user = $_POST['id_user'];
		$hub_pelap = $_POST['hub_pelap'];
		$nama_korban = $_POST['nama_korban'];
		$jk_korban = $_POST['jk_korban'];
		$usia_korb = $_POST['usia_korb'];
		$alamat_korban = $_POST['alamat_korban'];
		$nm_pelaku = $_POST['nm_pelaku'];
		$jk_pelaku = $_POST['jk_pelaku'];
		$alamat_pelaku = $_POST['alamat_pelaku'];
		$hub_pelaku = $_POST['hub_pelaku'];
			$jenis_ks = $_POST['jenis_ks'];
		$tgl_kej = $_POST['tgl_kej'];
		$kronologi = $_POST['kronologi'];
		$status = $_POST['status'];
		$gambar = $_POST['gambar'];
	
        //query untuk menambahkan data
		$query = "INSERT INTO pelaporan VALUES (null, '$id_user', '$hub_pelap', '$nama_korban', '$jk_korban', '$usia_korb', '$alamat_korban', '$nm_pelaku', '$jk_pelaku', '$alamat_pelaku',
		'$hub_pelaku', '$jenis_ks', '$tgl_kej', '$kronologi', '$status', '$gambar')";

		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'Data berhasil disimpan')) : json_encode(array('code' => 400, 'message' => 'data gagal disimpan'));
	} else{
		echo json_encode(array('code' => 404, 'message' => 'request tidak valid'));
	}
 ?>