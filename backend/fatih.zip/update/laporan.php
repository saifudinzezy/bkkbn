<?php 
    include '../koneksi.php';
    $query = "";
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_POST['id'];
        $status = $_POST['status'];
        $pesan = $_POST['pesan'];

        $query = "UPDATE pelaporan SET status='$status', pesan='$pesan' WHERE id_lapor='$id'";
        
        $exeQuery = mysqli_query($con, $query);

        echo ($exeQuery) ? json_encode(array('code' =>200, 'message' => 'Data berhasil ubah')) : json_encode(array('code' =>400, 'message' => 'data gagal diubah'));
    }   else {
        echo json_encode(array('code' =>404, 'message' => 'request tidak valid'));
        }
 ?>