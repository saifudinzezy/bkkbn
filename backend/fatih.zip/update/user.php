<?php 
	include '../koneksi.php';
	$query = "";
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$nik = $_POST['nik'];
		$password = $_POST['password'];

		$query = "UPDATE user SET password='$password' WHERE nik='$nik'";
		
		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' =>200, 'message' => 'Data berhasil ubah')) : json_encode(array('code' =>400, 'message' => 'data gagal diubah'));
	}	else {
		echo json_encode(array('code' =>404, 'message' => 'request tidak valid'));
		}
 ?>