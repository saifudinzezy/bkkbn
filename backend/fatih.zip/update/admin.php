<?php 
	include '../koneksi.php';
	$query = "";
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$id_admin = $_POST['id_admin'];
		$nama = $_POST['nama'];
		$email = $_POST['email'];
		$sandi = $_POST['sandi'];

		$query = "UPDATE admin SET nama='$nama', email='$email', sandi='$sandi'
				 WHERE id_admin='$id_admin'";
		
		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' =>200, 'message' => 'Data berhasil ubah')) : json_encode(array('code' =>400, 'message' => 'data gagal diubah'));
	}	else {
		echo json_encode(array('code' =>404, 'message' => 'request tidak valid'));
		}
 ?>