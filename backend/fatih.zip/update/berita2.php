<?php 
	//masukan koneksi
	include '../koneksi.php';
    $response = array();

    //buat var
    $code = "";
	$message = "";

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
		//ambil data dari user
		$id = $_POST['id'];
		$judul = str_replace("\"", "", $_POST['judul']);
		$artikel = str_replace("\"", "", $_POST['artikel']);					
		$tanggal = str_replace("\"", "", $_POST['tanggal']);
	
		//belum selesai			
		$query = "UPDATE berita SET judul='$judul', tanggal='$tanggal', artikel='$artikel' WHERE id_berita = '$id'";
		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' =>200, 'message' => 'data berhasil ubah')) : json_encode(array('code' =>404, 'message' => 'data gagal diubah'));	
	}else{
			echo json_encode(array('code' =>101, 'message' => 'request tidak valid'));
	}
 ?>